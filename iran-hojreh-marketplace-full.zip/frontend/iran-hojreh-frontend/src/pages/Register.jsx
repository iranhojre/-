
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'customer' });
  const navigate = useNavigate();

  const handleRegister = async () => {
    try {
      await axios.post('http://localhost:5000/auth/register', form);
      navigate('/login');
    } catch (err) {
      alert('ثبت‌نام ناموفق');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl mb-4">ثبت‌نام</h1>
      <input className="border w-full p-2 mb-2" placeholder="نام" onChange={e => setForm({ ...form, name: e.target.value })} />
      <input className="border w-full p-2 mb-2" placeholder="ایمیل" onChange={e => setForm({ ...form, email: e.target.value })} />
      <input className="border w-full p-2 mb-2" type="password" placeholder="رمز" onChange={e => setForm({ ...form, password: e.target.value })} />
      <select className="border w-full p-2 mb-2" onChange={e => setForm({ ...form, role: e.target.value })}>
        <option value="customer">مشتری</option>
        <option value="seller">فروشنده</option>
      </select>
      <button className="bg-green-500 text-white w-full py-2" onClick={handleRegister}>ثبت‌نام</button>
    </div>
  );
}
