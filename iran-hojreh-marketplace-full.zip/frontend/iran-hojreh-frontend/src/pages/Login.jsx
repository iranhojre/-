
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await axios.post('http://localhost:5000/auth/login', { email, password });
      localStorage.setItem('token', res.data.token);
      navigate('/');
    } catch (err) {
      alert('ورود ناموفق');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl mb-4">ورود</h1>
      <input className="border w-full p-2 mb-2" placeholder="ایمیل" onChange={e => setEmail(e.target.value)} />
      <input className="border w-full p-2 mb-2" type="password" placeholder="رمز" onChange={e => setPassword(e.target.value)} />
      <button className="bg-blue-500 text-white w-full py-2" onClick={handleLogin}>ورود</button>
    </div>
  );
}
