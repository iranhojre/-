
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

export default function Chat() {
  const { id } = useParams();
  const [conversation, setConversation] = useState(null);
  const [text, setText] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/conversations/' + id)
      .then(res => setConversation(res.data[0]))
      .catch(() => alert('خطا در دریافت چت'));
  }, [id]);

  const sendMessage = async () => {
    await axios.post(`http://localhost:5000/conversations/${conversation._id}/messages`, {
      sender: 'user',
      text,
    });
    setText('');
    const updated = await axios.get('http://localhost:5000/conversations/' + id);
    setConversation(updated.data[0]);
  };

  return (
    <div className="p-4">
      <div className="mb-4 h-64 overflow-y-scroll border p-2">
        {conversation?.messages.map((msg, i) => (
          <div key={i} className="mb-2">
            <b>{msg.sender}</b>: {msg.text}
          </div>
        ))}
      </div>
      <input className="border w-full p-2 mb-2" value={text} onChange={e => setText(e.target.value)} />
      <button className="bg-blue-500 text-white py-2 px-4" onClick={sendMessage}>ارسال</button>
    </div>
  );
}
