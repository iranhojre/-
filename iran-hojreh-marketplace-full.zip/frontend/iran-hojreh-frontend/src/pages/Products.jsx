
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/products')
      .then(res => setProducts(res.data))
      .catch(() => alert('خطا در دریافت محصولات'));
  }, []);

  return (
    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {products.map(p => (
        <div key={p._id} className="border p-4 rounded shadow">
          <h2 className="text-lg font-bold">{p.name}</h2>
          <p>{p.description}</p>
          <p className="text-blue-500">{p.price} تومان</p>
        </div>
      ))}
    </div>
  );
}
