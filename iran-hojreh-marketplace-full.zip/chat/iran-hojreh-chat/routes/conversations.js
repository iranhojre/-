
const express = require('express');
const router = express.Router();
const Conversation = require('../models/Conversation');

router.post('/', async (req, res) => {
  const { customerId, sellerId, firstMessage } = req.body;
  try {
    const conversation = new Conversation({
      customerId,
      sellerId,
      messages: [{ sender: customerId, text: firstMessage }]
    });
    await conversation.save();
    res.status(201).json(conversation);
  } catch (err) {
    res.status(500).json({ error: 'خطا در ایجاد گفت‌وگو' });
  }
});

router.post('/:id/messages', async (req, res) => {
  const { sender, text } = req.body;
  try {
    const conversation = await Conversation.findById(req.params.id);
    if (!conversation) return res.status(404).json({ error: 'گفت‌وگو پیدا نشد' });

    conversation.messages.push({ sender, text });
    conversation.lastUpdated = new Date();
    await conversation.save();

    res.json(conversation);
  } catch (err) {
    res.status(500).json({ error: 'خطا در افزودن پیام' });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const conversations = await Conversation.find({
      $or: [{ customerId: req.params.userId }, { sellerId: req.params.userId }]
    }).sort({ lastUpdated: -1 });
    res.json(conversations);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت گفت‌وگوها' });
  }
});

module.exports = router;
