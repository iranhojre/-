# پروژه بازار مجازی ایران حجره

این پروژه شامل سه بخش اصلی است:
1. **بک‌اند (Backend):** مدیریت کاربران، محصولات، سفارشات و سایر منطق بازار.
2. **فرانت‌اند (Frontend):** رابط کاربری React با TailwindCSS و Vite.
3. **سرویس چت (Chat):** میکروسرویس جداگانه برای گفت‌وگو بین کاربران و فروشندگان.

---

## راه‌اندازی بک‌اند

### پیش‌نیازها
- Node.js (نسخه 18 یا بالاتر)
- MongoDB

### نصب و اجرا
```bash
cd backend
npm install
npm run dev
```

### تنظیمات مورد نیاز
فایل `.env` با محتوای زیر ایجاد کنید:
```env
MONGODB_URI=mongodb://localhost:27017/iran-hojreh
PORT=5000
```

---

## راه‌اندازی فرانت‌اند

### پیش‌نیازها
- Node.js

### نصب و اجرا
```bash
cd frontend/iran-hojreh-frontend
npm install
npm run dev
```

---

## راه‌اندازی سرویس چت

### پیش‌نیازها
- Node.js
- MongoDB

### نصب و اجرا
```bash
cd chat/iran-hojreh-chat
npm install
npm run dev
```

### تنظیمات مورد نیاز
فایل `.env` با محتوای زیر ایجاد کنید:
```env
MONGODB_URI=mongodb://localhost:27017/iran-hojreh-chat
PORT=5001
```

---

## ساختار پوشه‌ها
```
├── backend
├── frontend
│   └── iran-hojreh-frontend
└── chat
    └── iran-hojreh-chat
```

## توسعه‌دهنده
پروژه توسط [تیم توسعه ایران حجره] ساخته شده است.