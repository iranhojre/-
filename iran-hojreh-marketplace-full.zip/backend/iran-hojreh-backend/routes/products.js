const express = require('express');
const router = express.Router();

// Sample route
router.get('/', (req, res) => {
  res.send('Product list');
});

module.exports = router;